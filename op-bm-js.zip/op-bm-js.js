$('#header-search').append('<div id="phonenumber">(716) 714-9708</div>');
