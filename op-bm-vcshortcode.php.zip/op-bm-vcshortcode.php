<?php
	
/*
Plugin Name: OP-BM Add Visual Composer Shortcode
Plugin URI: 
Description: creates a function container queued by a VC compatible shortcode
Version: 0.2
Author: Bean Media
Author URI: http://www.beanmediaproductions.com
*/

add_filter( 'vc_grid_item_shortcodes', 'my_module_add_grid_shortcodes' );
function my_module_add_grid_shortcodes( $shortcodes ) {
   $shortcodes['vc_say_hello'] = array(
     'name' => __( 'Say Hello', 'my-text-domain' ),
     'base' => 'vc_say_hello',
     'category' => __( 'Content', 'my-text-domain' ),
     'description' => __( 'Just outputs Hello World', 'my-text-domain' ),
     'post_type' => Vc_Grid_Item_Editor::postType(),
  );
   return $shortcodes;
}
 
add_shortcode( 'vc_say_hello', 'vc_say_hello_render' );
function vc_say_hello_render() {
   return '<h2>Hello, World!</h2>';
}

?>