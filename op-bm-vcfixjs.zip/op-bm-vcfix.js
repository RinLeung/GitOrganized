console.log (Array.from(document.querySelector('#tm-content > article > div:nth-child(5) > div > ul').children))

